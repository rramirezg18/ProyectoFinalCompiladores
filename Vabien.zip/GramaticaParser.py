# Generated from Gramatica.g4 by ANTLR 4.13.1
# encoding: utf-8
from antlr4 import *
from io import StringIO
import sys
if sys.version_info[1] > 5:
	from typing import TextIO
else:
	from typing.io import TextIO

def serializedATN():
    return [
        4,1,39,243,2,0,7,0,2,1,7,1,2,2,7,2,2,3,7,3,2,4,7,4,2,5,7,5,2,6,7,
        6,2,7,7,7,2,8,7,8,2,9,7,9,2,10,7,10,2,11,7,11,2,12,7,12,2,13,7,13,
        2,14,7,14,2,15,7,15,2,16,7,16,2,17,7,17,2,18,7,18,2,19,7,19,2,20,
        7,20,2,21,7,21,2,22,7,22,1,0,1,0,1,0,1,0,5,0,51,8,0,10,0,12,0,54,
        9,0,1,0,1,0,1,0,1,1,1,1,1,1,1,1,1,1,5,1,64,8,1,10,1,12,1,67,9,1,
        1,1,1,1,1,2,1,2,1,2,1,2,1,2,1,2,1,2,3,2,78,8,2,1,3,3,3,81,8,3,1,
        3,1,3,1,3,1,3,1,3,1,4,1,4,1,5,1,5,1,5,1,5,1,5,1,5,1,6,1,6,1,6,1,
        6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,1,6,5,6,108,8,6,10,6,12,6,111,9,6,
        1,6,1,6,3,6,115,8,6,1,7,1,7,1,7,1,7,1,7,1,7,1,8,1,8,1,8,1,8,1,8,
        1,8,1,8,1,8,1,8,1,9,1,9,1,9,3,9,135,8,9,1,10,1,10,1,10,1,10,1,11,
        1,11,1,11,1,11,3,11,145,8,11,1,11,1,11,1,11,5,11,150,8,11,10,11,
        12,11,153,9,11,1,11,3,11,156,8,11,1,11,1,11,1,12,1,12,1,12,1,12,
        1,12,1,12,5,12,166,8,12,10,12,12,12,169,9,12,1,13,1,13,1,13,5,13,
        174,8,13,10,13,12,13,177,9,13,1,14,1,14,1,14,3,14,182,8,14,1,14,
        1,14,3,14,186,8,14,1,15,1,15,4,15,190,8,15,11,15,12,15,191,1,15,
        1,15,1,16,1,16,1,17,1,17,1,17,5,17,201,8,17,10,17,12,17,204,9,17,
        1,18,1,18,1,18,5,18,209,8,18,10,18,12,18,212,9,18,1,19,1,19,1,19,
        5,19,217,8,19,10,19,12,19,220,9,19,1,20,1,20,1,20,3,20,225,8,20,
        1,21,1,21,1,21,3,21,230,8,21,1,22,1,22,1,22,1,22,1,22,1,22,1,22,
        1,22,1,22,3,22,241,8,22,1,22,0,0,23,0,2,4,6,8,10,12,14,16,18,20,
        22,24,26,28,30,32,34,36,38,40,42,44,0,5,1,0,23,26,1,0,21,22,1,0,
        15,20,1,0,9,10,2,0,11,12,14,14,249,0,46,1,0,0,0,2,58,1,0,0,0,4,77,
        1,0,0,0,6,80,1,0,0,0,8,87,1,0,0,0,10,89,1,0,0,0,12,95,1,0,0,0,14,
        116,1,0,0,0,16,122,1,0,0,0,18,134,1,0,0,0,20,136,1,0,0,0,22,140,
        1,0,0,0,24,159,1,0,0,0,26,170,1,0,0,0,28,178,1,0,0,0,30,187,1,0,
        0,0,32,195,1,0,0,0,34,197,1,0,0,0,36,205,1,0,0,0,38,213,1,0,0,0,
        40,221,1,0,0,0,42,229,1,0,0,0,44,240,1,0,0,0,46,47,5,27,0,0,47,48,
        5,33,0,0,48,52,3,2,1,0,49,51,3,22,11,0,50,49,1,0,0,0,51,54,1,0,0,
        0,52,50,1,0,0,0,52,53,1,0,0,0,53,55,1,0,0,0,54,52,1,0,0,0,55,56,
        5,34,0,0,56,57,5,0,0,1,57,1,1,0,0,0,58,59,5,1,0,0,59,60,5,31,0,0,
        60,61,5,32,0,0,61,65,5,33,0,0,62,64,3,4,2,0,63,62,1,0,0,0,64,67,
        1,0,0,0,65,63,1,0,0,0,65,66,1,0,0,0,66,68,1,0,0,0,67,65,1,0,0,0,
        68,69,5,34,0,0,69,3,1,0,0,0,70,78,3,6,3,0,71,78,3,10,5,0,72,78,3,
        12,6,0,73,78,3,14,7,0,74,78,3,16,8,0,75,78,3,20,10,0,76,78,3,28,
        14,0,77,70,1,0,0,0,77,71,1,0,0,0,77,72,1,0,0,0,77,73,1,0,0,0,77,
        74,1,0,0,0,77,75,1,0,0,0,77,76,1,0,0,0,78,5,1,0,0,0,79,81,3,8,4,
        0,80,79,1,0,0,0,80,81,1,0,0,0,81,82,1,0,0,0,82,83,5,27,0,0,83,84,
        5,8,0,0,84,85,3,32,16,0,85,86,5,35,0,0,86,7,1,0,0,0,87,88,7,0,0,
        0,88,9,1,0,0,0,89,90,5,6,0,0,90,91,5,31,0,0,91,92,3,32,16,0,92,93,
        5,32,0,0,93,94,5,35,0,0,94,11,1,0,0,0,95,96,5,2,0,0,96,97,5,31,0,
        0,97,98,3,32,16,0,98,99,5,32,0,0,99,109,3,30,15,0,100,101,5,3,0,
        0,101,102,5,2,0,0,102,103,5,31,0,0,103,104,3,32,16,0,104,105,5,32,
        0,0,105,106,3,30,15,0,106,108,1,0,0,0,107,100,1,0,0,0,108,111,1,
        0,0,0,109,107,1,0,0,0,109,110,1,0,0,0,110,114,1,0,0,0,111,109,1,
        0,0,0,112,113,5,3,0,0,113,115,3,30,15,0,114,112,1,0,0,0,114,115,
        1,0,0,0,115,13,1,0,0,0,116,117,5,4,0,0,117,118,5,31,0,0,118,119,
        3,32,16,0,119,120,5,32,0,0,120,121,3,30,15,0,121,15,1,0,0,0,122,
        123,5,5,0,0,123,124,5,31,0,0,124,125,3,6,3,0,125,126,3,32,16,0,126,
        127,5,35,0,0,127,128,3,18,9,0,128,129,5,32,0,0,129,130,3,30,15,0,
        130,17,1,0,0,0,131,132,5,27,0,0,132,135,7,1,0,0,133,135,3,6,3,0,
        134,131,1,0,0,0,134,133,1,0,0,0,135,19,1,0,0,0,136,137,5,7,0,0,137,
        138,3,32,16,0,138,139,5,35,0,0,139,21,1,0,0,0,140,141,3,8,4,0,141,
        142,5,27,0,0,142,144,5,31,0,0,143,145,3,24,12,0,144,143,1,0,0,0,
        144,145,1,0,0,0,145,146,1,0,0,0,146,147,5,32,0,0,147,151,5,33,0,
        0,148,150,3,4,2,0,149,148,1,0,0,0,150,153,1,0,0,0,151,149,1,0,0,
        0,151,152,1,0,0,0,152,155,1,0,0,0,153,151,1,0,0,0,154,156,3,20,10,
        0,155,154,1,0,0,0,155,156,1,0,0,0,156,157,1,0,0,0,157,158,5,34,0,
        0,158,23,1,0,0,0,159,160,3,8,4,0,160,167,5,27,0,0,161,162,5,36,0,
        0,162,163,3,8,4,0,163,164,5,27,0,0,164,166,1,0,0,0,165,161,1,0,0,
        0,166,169,1,0,0,0,167,165,1,0,0,0,167,168,1,0,0,0,168,25,1,0,0,0,
        169,167,1,0,0,0,170,175,3,32,16,0,171,172,5,36,0,0,172,174,3,32,
        16,0,173,171,1,0,0,0,174,177,1,0,0,0,175,173,1,0,0,0,175,176,1,0,
        0,0,176,27,1,0,0,0,177,175,1,0,0,0,178,179,5,27,0,0,179,181,5,31,
        0,0,180,182,3,26,13,0,181,180,1,0,0,0,181,182,1,0,0,0,182,183,1,
        0,0,0,183,185,5,32,0,0,184,186,5,35,0,0,185,184,1,0,0,0,185,186,
        1,0,0,0,186,29,1,0,0,0,187,189,5,33,0,0,188,190,3,4,2,0,189,188,
        1,0,0,0,190,191,1,0,0,0,191,189,1,0,0,0,191,192,1,0,0,0,192,193,
        1,0,0,0,193,194,5,34,0,0,194,31,1,0,0,0,195,196,3,34,17,0,196,33,
        1,0,0,0,197,202,3,36,18,0,198,199,7,2,0,0,199,201,3,36,18,0,200,
        198,1,0,0,0,201,204,1,0,0,0,202,200,1,0,0,0,202,203,1,0,0,0,203,
        35,1,0,0,0,204,202,1,0,0,0,205,210,3,38,19,0,206,207,7,3,0,0,207,
        209,3,38,19,0,208,206,1,0,0,0,209,212,1,0,0,0,210,208,1,0,0,0,210,
        211,1,0,0,0,211,37,1,0,0,0,212,210,1,0,0,0,213,218,3,40,20,0,214,
        215,7,4,0,0,215,217,3,40,20,0,216,214,1,0,0,0,217,220,1,0,0,0,218,
        216,1,0,0,0,218,219,1,0,0,0,219,39,1,0,0,0,220,218,1,0,0,0,221,224,
        3,42,21,0,222,223,5,13,0,0,223,225,3,40,20,0,224,222,1,0,0,0,224,
        225,1,0,0,0,225,41,1,0,0,0,226,227,5,10,0,0,227,230,3,42,21,0,228,
        230,3,44,22,0,229,226,1,0,0,0,229,228,1,0,0,0,230,43,1,0,0,0,231,
        232,5,31,0,0,232,233,3,32,16,0,233,234,5,32,0,0,234,241,1,0,0,0,
        235,241,3,28,14,0,236,241,5,27,0,0,237,241,5,28,0,0,238,241,5,29,
        0,0,239,241,5,30,0,0,240,231,1,0,0,0,240,235,1,0,0,0,240,236,1,0,
        0,0,240,237,1,0,0,0,240,238,1,0,0,0,240,239,1,0,0,0,241,45,1,0,0,
        0,21,52,65,77,80,109,114,134,144,151,155,167,175,181,185,191,202,
        210,218,224,229,240
    ]

class GramaticaParser ( Parser ):

    grammarFileName = "Gramatica.g4"

    atn = ATNDeserializer().deserialize(serializedATN())

    decisionsToDFA = [ DFA(ds, i) for i, ds in enumerate(atn.decisionToState) ]

    sharedContextCache = PredictionContextCache()

    literalNames = [ "<INVALID>", "'main'", "'if'", "'else'", "'while'", 
                     "'for'", "'print'", "'return'", "'='", "'+'", "'-'", 
                     "'*'", "'/'", "'^'", "'%'", "'=='", "'!='", "'<'", 
                     "'>'", "'<='", "'>='", "'++'", "'--'", "'int'", "'float'", 
                     "'boolean'", "'string'", "<INVALID>", "<INVALID>", 
                     "<INVALID>", "<INVALID>", "'('", "')'", "'{'", "'}'", 
                     "';'", "','" ]

    symbolicNames = [ "<INVALID>", "MAIN", "IF", "ELSE", "WHILE", "FOR", 
                      "PRINT", "RETURN", "ASIGNACION", "MAS", "MENOS", "MULTIPLICACION", 
                      "DIVISION", "POTENCIA", "MOD", "IGUAL", "DIFERENTE", 
                      "MENOR", "MAYOR", "MENOR_IGUAL_QUE", "MAYOR_IGUAL_QUE", 
                      "MASMAS", "MENOSMENOS", "INT", "FLOAT", "BOOLEAN", 
                      "STRING", "VARIABLE", "NUMERO", "CADENA", "BOOLEANO", 
                      "PARENTESIS_APERTURA", "PARENTESIS_CIERRE", "LLAVE_APERTURA", 
                      "LLAVE_CIERRE", "FIN_DE_LINEA", "COMA", "WS", "COMENTARIO_LINEA", 
                      "COMENTARIO_MULTILINEA" ]

    RULE_gramatica = 0
    RULE_main = 1
    RULE_instruccion = 2
    RULE_declaracion_y_asignacion = 3
    RULE_tipo = 4
    RULE_sentencia_print = 5
    RULE_sentencia_if = 6
    RULE_sentencia_while = 7
    RULE_sentencia_for = 8
    RULE_for_incremento_y_disminucion = 9
    RULE_sentencia_return = 10
    RULE_funcion = 11
    RULE_parametros = 12
    RULE_argumentos = 13
    RULE_llamada_funcion = 14
    RULE_bloque = 15
    RULE_expr = 16
    RULE_relExpr = 17
    RULE_addExpr = 18
    RULE_mulExpr = 19
    RULE_powExpr = 20
    RULE_unaryExpr = 21
    RULE_atom = 22

    ruleNames =  [ "gramatica", "main", "instruccion", "declaracion_y_asignacion", 
                   "tipo", "sentencia_print", "sentencia_if", "sentencia_while", 
                   "sentencia_for", "for_incremento_y_disminucion", "sentencia_return", 
                   "funcion", "parametros", "argumentos", "llamada_funcion", 
                   "bloque", "expr", "relExpr", "addExpr", "mulExpr", "powExpr", 
                   "unaryExpr", "atom" ]

    EOF = Token.EOF
    MAIN=1
    IF=2
    ELSE=3
    WHILE=4
    FOR=5
    PRINT=6
    RETURN=7
    ASIGNACION=8
    MAS=9
    MENOS=10
    MULTIPLICACION=11
    DIVISION=12
    POTENCIA=13
    MOD=14
    IGUAL=15
    DIFERENTE=16
    MENOR=17
    MAYOR=18
    MENOR_IGUAL_QUE=19
    MAYOR_IGUAL_QUE=20
    MASMAS=21
    MENOSMENOS=22
    INT=23
    FLOAT=24
    BOOLEAN=25
    STRING=26
    VARIABLE=27
    NUMERO=28
    CADENA=29
    BOOLEANO=30
    PARENTESIS_APERTURA=31
    PARENTESIS_CIERRE=32
    LLAVE_APERTURA=33
    LLAVE_CIERRE=34
    FIN_DE_LINEA=35
    COMA=36
    WS=37
    COMENTARIO_LINEA=38
    COMENTARIO_MULTILINEA=39

    def __init__(self, input:TokenStream, output:TextIO = sys.stdout):
        super().__init__(input, output)
        self.checkVersion("4.13.1")
        self._interp = ParserATNSimulator(self, self.atn, self.decisionsToDFA, self.sharedContextCache)
        self._predicates = None




    class GramaticaContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE(self):
            return self.getToken(GramaticaParser.VARIABLE, 0)

        def LLAVE_APERTURA(self):
            return self.getToken(GramaticaParser.LLAVE_APERTURA, 0)

        def main(self):
            return self.getTypedRuleContext(GramaticaParser.MainContext,0)


        def LLAVE_CIERRE(self):
            return self.getToken(GramaticaParser.LLAVE_CIERRE, 0)

        def EOF(self):
            return self.getToken(GramaticaParser.EOF, 0)

        def funcion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.FuncionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.FuncionContext,i)


        def getRuleIndex(self):
            return GramaticaParser.RULE_gramatica

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterGramatica" ):
                listener.enterGramatica(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitGramatica" ):
                listener.exitGramatica(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitGramatica" ):
                return visitor.visitGramatica(self)
            else:
                return visitor.visitChildren(self)




    def gramatica(self):

        localctx = GramaticaParser.GramaticaContext(self, self._ctx, self.state)
        self.enterRule(localctx, 0, self.RULE_gramatica)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 46
            self.match(GramaticaParser.VARIABLE)
            self.state = 47
            self.match(GramaticaParser.LLAVE_APERTURA)
            self.state = 48
            self.main()
            self.state = 52
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 125829120) != 0):
                self.state = 49
                self.funcion()
                self.state = 54
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 55
            self.match(GramaticaParser.LLAVE_CIERRE)
            self.state = 56
            self.match(GramaticaParser.EOF)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MainContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MAIN(self):
            return self.getToken(GramaticaParser.MAIN, 0)

        def PARENTESIS_APERTURA(self):
            return self.getToken(GramaticaParser.PARENTESIS_APERTURA, 0)

        def PARENTESIS_CIERRE(self):
            return self.getToken(GramaticaParser.PARENTESIS_CIERRE, 0)

        def LLAVE_APERTURA(self):
            return self.getToken(GramaticaParser.LLAVE_APERTURA, 0)

        def LLAVE_CIERRE(self):
            return self.getToken(GramaticaParser.LLAVE_CIERRE, 0)

        def instruccion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.InstruccionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.InstruccionContext,i)


        def getRuleIndex(self):
            return GramaticaParser.RULE_main

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMain" ):
                listener.enterMain(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMain" ):
                listener.exitMain(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMain" ):
                return visitor.visitMain(self)
            else:
                return visitor.visitChildren(self)




    def main(self):

        localctx = GramaticaParser.MainContext(self, self._ctx, self.state)
        self.enterRule(localctx, 2, self.RULE_main)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 58
            self.match(GramaticaParser.MAIN)
            self.state = 59
            self.match(GramaticaParser.PARENTESIS_APERTURA)
            self.state = 60
            self.match(GramaticaParser.PARENTESIS_CIERRE)
            self.state = 61
            self.match(GramaticaParser.LLAVE_APERTURA)
            self.state = 65
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 260047092) != 0):
                self.state = 62
                self.instruccion()
                self.state = 67
                self._errHandler.sync(self)
                _la = self._input.LA(1)

            self.state = 68
            self.match(GramaticaParser.LLAVE_CIERRE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class InstruccionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def declaracion_y_asignacion(self):
            return self.getTypedRuleContext(GramaticaParser.Declaracion_y_asignacionContext,0)


        def sentencia_print(self):
            return self.getTypedRuleContext(GramaticaParser.Sentencia_printContext,0)


        def sentencia_if(self):
            return self.getTypedRuleContext(GramaticaParser.Sentencia_ifContext,0)


        def sentencia_while(self):
            return self.getTypedRuleContext(GramaticaParser.Sentencia_whileContext,0)


        def sentencia_for(self):
            return self.getTypedRuleContext(GramaticaParser.Sentencia_forContext,0)


        def sentencia_return(self):
            return self.getTypedRuleContext(GramaticaParser.Sentencia_returnContext,0)


        def llamada_funcion(self):
            return self.getTypedRuleContext(GramaticaParser.Llamada_funcionContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_instruccion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterInstruccion" ):
                listener.enterInstruccion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitInstruccion" ):
                listener.exitInstruccion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitInstruccion" ):
                return visitor.visitInstruccion(self)
            else:
                return visitor.visitChildren(self)




    def instruccion(self):

        localctx = GramaticaParser.InstruccionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 4, self.RULE_instruccion)
        try:
            self.state = 77
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,2,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 70
                self.declaracion_y_asignacion()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 71
                self.sentencia_print()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 72
                self.sentencia_if()
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 73
                self.sentencia_while()
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 74
                self.sentencia_for()
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 75
                self.sentencia_return()
                pass

            elif la_ == 7:
                self.enterOuterAlt(localctx, 7)
                self.state = 76
                self.llamada_funcion()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Declaracion_y_asignacionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE(self):
            return self.getToken(GramaticaParser.VARIABLE, 0)

        def ASIGNACION(self):
            return self.getToken(GramaticaParser.ASIGNACION, 0)

        def expr(self):
            return self.getTypedRuleContext(GramaticaParser.ExprContext,0)


        def FIN_DE_LINEA(self):
            return self.getToken(GramaticaParser.FIN_DE_LINEA, 0)

        def tipo(self):
            return self.getTypedRuleContext(GramaticaParser.TipoContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_declaracion_y_asignacion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterDeclaracion_y_asignacion" ):
                listener.enterDeclaracion_y_asignacion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitDeclaracion_y_asignacion" ):
                listener.exitDeclaracion_y_asignacion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitDeclaracion_y_asignacion" ):
                return visitor.visitDeclaracion_y_asignacion(self)
            else:
                return visitor.visitChildren(self)




    def declaracion_y_asignacion(self):

        localctx = GramaticaParser.Declaracion_y_asignacionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 6, self.RULE_declaracion_y_asignacion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 80
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 125829120) != 0):
                self.state = 79
                self.tipo()


            self.state = 82
            self.match(GramaticaParser.VARIABLE)
            self.state = 83
            self.match(GramaticaParser.ASIGNACION)
            self.state = 84
            self.expr()
            self.state = 85
            self.match(GramaticaParser.FIN_DE_LINEA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class TipoContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def INT(self):
            return self.getToken(GramaticaParser.INT, 0)

        def FLOAT(self):
            return self.getToken(GramaticaParser.FLOAT, 0)

        def BOOLEAN(self):
            return self.getToken(GramaticaParser.BOOLEAN, 0)

        def STRING(self):
            return self.getToken(GramaticaParser.STRING, 0)

        def getRuleIndex(self):
            return GramaticaParser.RULE_tipo

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterTipo" ):
                listener.enterTipo(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitTipo" ):
                listener.exitTipo(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitTipo" ):
                return visitor.visitTipo(self)
            else:
                return visitor.visitChildren(self)




    def tipo(self):

        localctx = GramaticaParser.TipoContext(self, self._ctx, self.state)
        self.enterRule(localctx, 8, self.RULE_tipo)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 87
            _la = self._input.LA(1)
            if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 125829120) != 0)):
                self._errHandler.recoverInline(self)
            else:
                self._errHandler.reportMatch(self)
                self.consume()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sentencia_printContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PRINT(self):
            return self.getToken(GramaticaParser.PRINT, 0)

        def PARENTESIS_APERTURA(self):
            return self.getToken(GramaticaParser.PARENTESIS_APERTURA, 0)

        def expr(self):
            return self.getTypedRuleContext(GramaticaParser.ExprContext,0)


        def PARENTESIS_CIERRE(self):
            return self.getToken(GramaticaParser.PARENTESIS_CIERRE, 0)

        def FIN_DE_LINEA(self):
            return self.getToken(GramaticaParser.FIN_DE_LINEA, 0)

        def getRuleIndex(self):
            return GramaticaParser.RULE_sentencia_print

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSentencia_print" ):
                listener.enterSentencia_print(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSentencia_print" ):
                listener.exitSentencia_print(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSentencia_print" ):
                return visitor.visitSentencia_print(self)
            else:
                return visitor.visitChildren(self)




    def sentencia_print(self):

        localctx = GramaticaParser.Sentencia_printContext(self, self._ctx, self.state)
        self.enterRule(localctx, 10, self.RULE_sentencia_print)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 89
            self.match(GramaticaParser.PRINT)
            self.state = 90
            self.match(GramaticaParser.PARENTESIS_APERTURA)
            self.state = 91
            self.expr()
            self.state = 92
            self.match(GramaticaParser.PARENTESIS_CIERRE)
            self.state = 93
            self.match(GramaticaParser.FIN_DE_LINEA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sentencia_ifContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def IF(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.IF)
            else:
                return self.getToken(GramaticaParser.IF, i)

        def PARENTESIS_APERTURA(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.PARENTESIS_APERTURA)
            else:
                return self.getToken(GramaticaParser.PARENTESIS_APERTURA, i)

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.ExprContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.ExprContext,i)


        def PARENTESIS_CIERRE(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.PARENTESIS_CIERRE)
            else:
                return self.getToken(GramaticaParser.PARENTESIS_CIERRE, i)

        def bloque(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.BloqueContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.BloqueContext,i)


        def ELSE(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.ELSE)
            else:
                return self.getToken(GramaticaParser.ELSE, i)

        def getRuleIndex(self):
            return GramaticaParser.RULE_sentencia_if

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSentencia_if" ):
                listener.enterSentencia_if(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSentencia_if" ):
                listener.exitSentencia_if(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSentencia_if" ):
                return visitor.visitSentencia_if(self)
            else:
                return visitor.visitChildren(self)




    def sentencia_if(self):

        localctx = GramaticaParser.Sentencia_ifContext(self, self._ctx, self.state)
        self.enterRule(localctx, 12, self.RULE_sentencia_if)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 95
            self.match(GramaticaParser.IF)
            self.state = 96
            self.match(GramaticaParser.PARENTESIS_APERTURA)
            self.state = 97
            self.expr()
            self.state = 98
            self.match(GramaticaParser.PARENTESIS_CIERRE)
            self.state = 99
            self.bloque()
            self.state = 109
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,4,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 100
                    self.match(GramaticaParser.ELSE)
                    self.state = 101
                    self.match(GramaticaParser.IF)
                    self.state = 102
                    self.match(GramaticaParser.PARENTESIS_APERTURA)
                    self.state = 103
                    self.expr()
                    self.state = 104
                    self.match(GramaticaParser.PARENTESIS_CIERRE)
                    self.state = 105
                    self.bloque() 
                self.state = 111
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,4,self._ctx)

            self.state = 114
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==3:
                self.state = 112
                self.match(GramaticaParser.ELSE)
                self.state = 113
                self.bloque()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sentencia_whileContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def WHILE(self):
            return self.getToken(GramaticaParser.WHILE, 0)

        def PARENTESIS_APERTURA(self):
            return self.getToken(GramaticaParser.PARENTESIS_APERTURA, 0)

        def expr(self):
            return self.getTypedRuleContext(GramaticaParser.ExprContext,0)


        def PARENTESIS_CIERRE(self):
            return self.getToken(GramaticaParser.PARENTESIS_CIERRE, 0)

        def bloque(self):
            return self.getTypedRuleContext(GramaticaParser.BloqueContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_sentencia_while

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSentencia_while" ):
                listener.enterSentencia_while(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSentencia_while" ):
                listener.exitSentencia_while(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSentencia_while" ):
                return visitor.visitSentencia_while(self)
            else:
                return visitor.visitChildren(self)




    def sentencia_while(self):

        localctx = GramaticaParser.Sentencia_whileContext(self, self._ctx, self.state)
        self.enterRule(localctx, 14, self.RULE_sentencia_while)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 116
            self.match(GramaticaParser.WHILE)
            self.state = 117
            self.match(GramaticaParser.PARENTESIS_APERTURA)
            self.state = 118
            self.expr()
            self.state = 119
            self.match(GramaticaParser.PARENTESIS_CIERRE)
            self.state = 120
            self.bloque()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sentencia_forContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def FOR(self):
            return self.getToken(GramaticaParser.FOR, 0)

        def PARENTESIS_APERTURA(self):
            return self.getToken(GramaticaParser.PARENTESIS_APERTURA, 0)

        def declaracion_y_asignacion(self):
            return self.getTypedRuleContext(GramaticaParser.Declaracion_y_asignacionContext,0)


        def expr(self):
            return self.getTypedRuleContext(GramaticaParser.ExprContext,0)


        def FIN_DE_LINEA(self):
            return self.getToken(GramaticaParser.FIN_DE_LINEA, 0)

        def for_incremento_y_disminucion(self):
            return self.getTypedRuleContext(GramaticaParser.For_incremento_y_disminucionContext,0)


        def PARENTESIS_CIERRE(self):
            return self.getToken(GramaticaParser.PARENTESIS_CIERRE, 0)

        def bloque(self):
            return self.getTypedRuleContext(GramaticaParser.BloqueContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_sentencia_for

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSentencia_for" ):
                listener.enterSentencia_for(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSentencia_for" ):
                listener.exitSentencia_for(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSentencia_for" ):
                return visitor.visitSentencia_for(self)
            else:
                return visitor.visitChildren(self)




    def sentencia_for(self):

        localctx = GramaticaParser.Sentencia_forContext(self, self._ctx, self.state)
        self.enterRule(localctx, 16, self.RULE_sentencia_for)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 122
            self.match(GramaticaParser.FOR)
            self.state = 123
            self.match(GramaticaParser.PARENTESIS_APERTURA)
            self.state = 124
            self.declaracion_y_asignacion()
            self.state = 125
            self.expr()
            self.state = 126
            self.match(GramaticaParser.FIN_DE_LINEA)
            self.state = 127
            self.for_incremento_y_disminucion()
            self.state = 128
            self.match(GramaticaParser.PARENTESIS_CIERRE)
            self.state = 129
            self.bloque()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class For_incremento_y_disminucionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE(self):
            return self.getToken(GramaticaParser.VARIABLE, 0)

        def MASMAS(self):
            return self.getToken(GramaticaParser.MASMAS, 0)

        def MENOSMENOS(self):
            return self.getToken(GramaticaParser.MENOSMENOS, 0)

        def declaracion_y_asignacion(self):
            return self.getTypedRuleContext(GramaticaParser.Declaracion_y_asignacionContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_for_incremento_y_disminucion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFor_incremento_y_disminucion" ):
                listener.enterFor_incremento_y_disminucion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFor_incremento_y_disminucion" ):
                listener.exitFor_incremento_y_disminucion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFor_incremento_y_disminucion" ):
                return visitor.visitFor_incremento_y_disminucion(self)
            else:
                return visitor.visitChildren(self)




    def for_incremento_y_disminucion(self):

        localctx = GramaticaParser.For_incremento_y_disminucionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 18, self.RULE_for_incremento_y_disminucion)
        self._la = 0 # Token type
        try:
            self.state = 134
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,6,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 131
                self.match(GramaticaParser.VARIABLE)
                self.state = 132
                _la = self._input.LA(1)
                if not(_la==21 or _la==22):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 133
                self.declaracion_y_asignacion()
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Sentencia_returnContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def RETURN(self):
            return self.getToken(GramaticaParser.RETURN, 0)

        def expr(self):
            return self.getTypedRuleContext(GramaticaParser.ExprContext,0)


        def FIN_DE_LINEA(self):
            return self.getToken(GramaticaParser.FIN_DE_LINEA, 0)

        def getRuleIndex(self):
            return GramaticaParser.RULE_sentencia_return

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterSentencia_return" ):
                listener.enterSentencia_return(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitSentencia_return" ):
                listener.exitSentencia_return(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitSentencia_return" ):
                return visitor.visitSentencia_return(self)
            else:
                return visitor.visitChildren(self)




    def sentencia_return(self):

        localctx = GramaticaParser.Sentencia_returnContext(self, self._ctx, self.state)
        self.enterRule(localctx, 20, self.RULE_sentencia_return)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 136
            self.match(GramaticaParser.RETURN)
            self.state = 137
            self.expr()
            self.state = 138
            self.match(GramaticaParser.FIN_DE_LINEA)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class FuncionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self):
            return self.getTypedRuleContext(GramaticaParser.TipoContext,0)


        def VARIABLE(self):
            return self.getToken(GramaticaParser.VARIABLE, 0)

        def PARENTESIS_APERTURA(self):
            return self.getToken(GramaticaParser.PARENTESIS_APERTURA, 0)

        def PARENTESIS_CIERRE(self):
            return self.getToken(GramaticaParser.PARENTESIS_CIERRE, 0)

        def LLAVE_APERTURA(self):
            return self.getToken(GramaticaParser.LLAVE_APERTURA, 0)

        def LLAVE_CIERRE(self):
            return self.getToken(GramaticaParser.LLAVE_CIERRE, 0)

        def parametros(self):
            return self.getTypedRuleContext(GramaticaParser.ParametrosContext,0)


        def instruccion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.InstruccionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.InstruccionContext,i)


        def sentencia_return(self):
            return self.getTypedRuleContext(GramaticaParser.Sentencia_returnContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_funcion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterFuncion" ):
                listener.enterFuncion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitFuncion" ):
                listener.exitFuncion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitFuncion" ):
                return visitor.visitFuncion(self)
            else:
                return visitor.visitChildren(self)




    def funcion(self):

        localctx = GramaticaParser.FuncionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 22, self.RULE_funcion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 140
            self.tipo()
            self.state = 141
            self.match(GramaticaParser.VARIABLE)
            self.state = 142
            self.match(GramaticaParser.PARENTESIS_APERTURA)
            self.state = 144
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 125829120) != 0):
                self.state = 143
                self.parametros()


            self.state = 146
            self.match(GramaticaParser.PARENTESIS_CIERRE)
            self.state = 147
            self.match(GramaticaParser.LLAVE_APERTURA)
            self.state = 151
            self._errHandler.sync(self)
            _alt = self._interp.adaptivePredict(self._input,8,self._ctx)
            while _alt!=2 and _alt!=ATN.INVALID_ALT_NUMBER:
                if _alt==1:
                    self.state = 148
                    self.instruccion() 
                self.state = 153
                self._errHandler.sync(self)
                _alt = self._interp.adaptivePredict(self._input,8,self._ctx)

            self.state = 155
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==7:
                self.state = 154
                self.sentencia_return()


            self.state = 157
            self.match(GramaticaParser.LLAVE_CIERRE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ParametrosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def tipo(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.TipoContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.TipoContext,i)


        def VARIABLE(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.VARIABLE)
            else:
                return self.getToken(GramaticaParser.VARIABLE, i)

        def COMA(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.COMA)
            else:
                return self.getToken(GramaticaParser.COMA, i)

        def getRuleIndex(self):
            return GramaticaParser.RULE_parametros

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterParametros" ):
                listener.enterParametros(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitParametros" ):
                listener.exitParametros(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitParametros" ):
                return visitor.visitParametros(self)
            else:
                return visitor.visitChildren(self)




    def parametros(self):

        localctx = GramaticaParser.ParametrosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 24, self.RULE_parametros)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 159
            self.tipo()
            self.state = 160
            self.match(GramaticaParser.VARIABLE)
            self.state = 167
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 161
                self.match(GramaticaParser.COMA)
                self.state = 162
                self.tipo()
                self.state = 163
                self.match(GramaticaParser.VARIABLE)
                self.state = 169
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ArgumentosContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def expr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.ExprContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.ExprContext,i)


        def COMA(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.COMA)
            else:
                return self.getToken(GramaticaParser.COMA, i)

        def getRuleIndex(self):
            return GramaticaParser.RULE_argumentos

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterArgumentos" ):
                listener.enterArgumentos(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitArgumentos" ):
                listener.exitArgumentos(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitArgumentos" ):
                return visitor.visitArgumentos(self)
            else:
                return visitor.visitChildren(self)




    def argumentos(self):

        localctx = GramaticaParser.ArgumentosContext(self, self._ctx, self.state)
        self.enterRule(localctx, 26, self.RULE_argumentos)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 170
            self.expr()
            self.state = 175
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==36:
                self.state = 171
                self.match(GramaticaParser.COMA)
                self.state = 172
                self.expr()
                self.state = 177
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class Llamada_funcionContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def VARIABLE(self):
            return self.getToken(GramaticaParser.VARIABLE, 0)

        def PARENTESIS_APERTURA(self):
            return self.getToken(GramaticaParser.PARENTESIS_APERTURA, 0)

        def PARENTESIS_CIERRE(self):
            return self.getToken(GramaticaParser.PARENTESIS_CIERRE, 0)

        def argumentos(self):
            return self.getTypedRuleContext(GramaticaParser.ArgumentosContext,0)


        def FIN_DE_LINEA(self):
            return self.getToken(GramaticaParser.FIN_DE_LINEA, 0)

        def getRuleIndex(self):
            return GramaticaParser.RULE_llamada_funcion

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterLlamada_funcion" ):
                listener.enterLlamada_funcion(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitLlamada_funcion" ):
                listener.exitLlamada_funcion(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitLlamada_funcion" ):
                return visitor.visitLlamada_funcion(self)
            else:
                return visitor.visitChildren(self)




    def llamada_funcion(self):

        localctx = GramaticaParser.Llamada_funcionContext(self, self._ctx, self.state)
        self.enterRule(localctx, 28, self.RULE_llamada_funcion)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 178
            self.match(GramaticaParser.VARIABLE)
            self.state = 179
            self.match(GramaticaParser.PARENTESIS_APERTURA)
            self.state = 181
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if (((_la) & ~0x3f) == 0 and ((1 << _la) & 4160750592) != 0):
                self.state = 180
                self.argumentos()


            self.state = 183
            self.match(GramaticaParser.PARENTESIS_CIERRE)
            self.state = 185
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,13,self._ctx)
            if la_ == 1:
                self.state = 184
                self.match(GramaticaParser.FIN_DE_LINEA)


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class BloqueContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def LLAVE_APERTURA(self):
            return self.getToken(GramaticaParser.LLAVE_APERTURA, 0)

        def LLAVE_CIERRE(self):
            return self.getToken(GramaticaParser.LLAVE_CIERRE, 0)

        def instruccion(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.InstruccionContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.InstruccionContext,i)


        def getRuleIndex(self):
            return GramaticaParser.RULE_bloque

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterBloque" ):
                listener.enterBloque(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitBloque" ):
                listener.exitBloque(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitBloque" ):
                return visitor.visitBloque(self)
            else:
                return visitor.visitChildren(self)




    def bloque(self):

        localctx = GramaticaParser.BloqueContext(self, self._ctx, self.state)
        self.enterRule(localctx, 30, self.RULE_bloque)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 187
            self.match(GramaticaParser.LLAVE_APERTURA)
            self.state = 189 
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while True:
                self.state = 188
                self.instruccion()
                self.state = 191 
                self._errHandler.sync(self)
                _la = self._input.LA(1)
                if not ((((_la) & ~0x3f) == 0 and ((1 << _la) & 260047092) != 0)):
                    break

            self.state = 193
            self.match(GramaticaParser.LLAVE_CIERRE)
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class ExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def relExpr(self):
            return self.getTypedRuleContext(GramaticaParser.RelExprContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_expr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterExpr" ):
                listener.enterExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitExpr" ):
                listener.exitExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitExpr" ):
                return visitor.visitExpr(self)
            else:
                return visitor.visitChildren(self)




    def expr(self):

        localctx = GramaticaParser.ExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 32, self.RULE_expr)
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 195
            self.relExpr()
        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class RelExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def addExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.AddExprContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.AddExprContext,i)


        def MAYOR(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MAYOR)
            else:
                return self.getToken(GramaticaParser.MAYOR, i)

        def MENOR(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MENOR)
            else:
                return self.getToken(GramaticaParser.MENOR, i)

        def MAYOR_IGUAL_QUE(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MAYOR_IGUAL_QUE)
            else:
                return self.getToken(GramaticaParser.MAYOR_IGUAL_QUE, i)

        def MENOR_IGUAL_QUE(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MENOR_IGUAL_QUE)
            else:
                return self.getToken(GramaticaParser.MENOR_IGUAL_QUE, i)

        def IGUAL(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.IGUAL)
            else:
                return self.getToken(GramaticaParser.IGUAL, i)

        def DIFERENTE(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.DIFERENTE)
            else:
                return self.getToken(GramaticaParser.DIFERENTE, i)

        def getRuleIndex(self):
            return GramaticaParser.RULE_relExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterRelExpr" ):
                listener.enterRelExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitRelExpr" ):
                listener.exitRelExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitRelExpr" ):
                return visitor.visitRelExpr(self)
            else:
                return visitor.visitChildren(self)




    def relExpr(self):

        localctx = GramaticaParser.RelExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 34, self.RULE_relExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 197
            self.addExpr()
            self.state = 202
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 2064384) != 0):
                self.state = 198
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 2064384) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 199
                self.addExpr()
                self.state = 204
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AddExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def mulExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.MulExprContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.MulExprContext,i)


        def MAS(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MAS)
            else:
                return self.getToken(GramaticaParser.MAS, i)

        def MENOS(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MENOS)
            else:
                return self.getToken(GramaticaParser.MENOS, i)

        def getRuleIndex(self):
            return GramaticaParser.RULE_addExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAddExpr" ):
                listener.enterAddExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAddExpr" ):
                listener.exitAddExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAddExpr" ):
                return visitor.visitAddExpr(self)
            else:
                return visitor.visitChildren(self)




    def addExpr(self):

        localctx = GramaticaParser.AddExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 36, self.RULE_addExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 205
            self.mulExpr()
            self.state = 210
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while _la==9 or _la==10:
                self.state = 206
                _la = self._input.LA(1)
                if not(_la==9 or _la==10):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 207
                self.mulExpr()
                self.state = 212
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class MulExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def powExpr(self, i:int=None):
            if i is None:
                return self.getTypedRuleContexts(GramaticaParser.PowExprContext)
            else:
                return self.getTypedRuleContext(GramaticaParser.PowExprContext,i)


        def MULTIPLICACION(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MULTIPLICACION)
            else:
                return self.getToken(GramaticaParser.MULTIPLICACION, i)

        def DIVISION(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.DIVISION)
            else:
                return self.getToken(GramaticaParser.DIVISION, i)

        def MOD(self, i:int=None):
            if i is None:
                return self.getTokens(GramaticaParser.MOD)
            else:
                return self.getToken(GramaticaParser.MOD, i)

        def getRuleIndex(self):
            return GramaticaParser.RULE_mulExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterMulExpr" ):
                listener.enterMulExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitMulExpr" ):
                listener.exitMulExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitMulExpr" ):
                return visitor.visitMulExpr(self)
            else:
                return visitor.visitChildren(self)




    def mulExpr(self):

        localctx = GramaticaParser.MulExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 38, self.RULE_mulExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 213
            self.powExpr()
            self.state = 218
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            while (((_la) & ~0x3f) == 0 and ((1 << _la) & 22528) != 0):
                self.state = 214
                _la = self._input.LA(1)
                if not((((_la) & ~0x3f) == 0 and ((1 << _la) & 22528) != 0)):
                    self._errHandler.recoverInline(self)
                else:
                    self._errHandler.reportMatch(self)
                    self.consume()
                self.state = 215
                self.powExpr()
                self.state = 220
                self._errHandler.sync(self)
                _la = self._input.LA(1)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class PowExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def unaryExpr(self):
            return self.getTypedRuleContext(GramaticaParser.UnaryExprContext,0)


        def POTENCIA(self):
            return self.getToken(GramaticaParser.POTENCIA, 0)

        def powExpr(self):
            return self.getTypedRuleContext(GramaticaParser.PowExprContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_powExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterPowExpr" ):
                listener.enterPowExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitPowExpr" ):
                listener.exitPowExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitPowExpr" ):
                return visitor.visitPowExpr(self)
            else:
                return visitor.visitChildren(self)




    def powExpr(self):

        localctx = GramaticaParser.PowExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 40, self.RULE_powExpr)
        self._la = 0 # Token type
        try:
            self.enterOuterAlt(localctx, 1)
            self.state = 221
            self.unaryExpr()
            self.state = 224
            self._errHandler.sync(self)
            _la = self._input.LA(1)
            if _la==13:
                self.state = 222
                self.match(GramaticaParser.POTENCIA)
                self.state = 223
                self.powExpr()


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class UnaryExprContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def MENOS(self):
            return self.getToken(GramaticaParser.MENOS, 0)

        def unaryExpr(self):
            return self.getTypedRuleContext(GramaticaParser.UnaryExprContext,0)


        def atom(self):
            return self.getTypedRuleContext(GramaticaParser.AtomContext,0)


        def getRuleIndex(self):
            return GramaticaParser.RULE_unaryExpr

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterUnaryExpr" ):
                listener.enterUnaryExpr(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitUnaryExpr" ):
                listener.exitUnaryExpr(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitUnaryExpr" ):
                return visitor.visitUnaryExpr(self)
            else:
                return visitor.visitChildren(self)




    def unaryExpr(self):

        localctx = GramaticaParser.UnaryExprContext(self, self._ctx, self.state)
        self.enterRule(localctx, 42, self.RULE_unaryExpr)
        try:
            self.state = 229
            self._errHandler.sync(self)
            token = self._input.LA(1)
            if token in [10]:
                self.enterOuterAlt(localctx, 1)
                self.state = 226
                self.match(GramaticaParser.MENOS)
                self.state = 227
                self.unaryExpr()
                pass
            elif token in [27, 28, 29, 30, 31]:
                self.enterOuterAlt(localctx, 2)
                self.state = 228
                self.atom()
                pass
            else:
                raise NoViableAltException(self)

        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx


    class AtomContext(ParserRuleContext):
        __slots__ = 'parser'

        def __init__(self, parser, parent:ParserRuleContext=None, invokingState:int=-1):
            super().__init__(parent, invokingState)
            self.parser = parser

        def PARENTESIS_APERTURA(self):
            return self.getToken(GramaticaParser.PARENTESIS_APERTURA, 0)

        def expr(self):
            return self.getTypedRuleContext(GramaticaParser.ExprContext,0)


        def PARENTESIS_CIERRE(self):
            return self.getToken(GramaticaParser.PARENTESIS_CIERRE, 0)

        def llamada_funcion(self):
            return self.getTypedRuleContext(GramaticaParser.Llamada_funcionContext,0)


        def VARIABLE(self):
            return self.getToken(GramaticaParser.VARIABLE, 0)

        def NUMERO(self):
            return self.getToken(GramaticaParser.NUMERO, 0)

        def CADENA(self):
            return self.getToken(GramaticaParser.CADENA, 0)

        def BOOLEANO(self):
            return self.getToken(GramaticaParser.BOOLEANO, 0)

        def getRuleIndex(self):
            return GramaticaParser.RULE_atom

        def enterRule(self, listener:ParseTreeListener):
            if hasattr( listener, "enterAtom" ):
                listener.enterAtom(self)

        def exitRule(self, listener:ParseTreeListener):
            if hasattr( listener, "exitAtom" ):
                listener.exitAtom(self)

        def accept(self, visitor:ParseTreeVisitor):
            if hasattr( visitor, "visitAtom" ):
                return visitor.visitAtom(self)
            else:
                return visitor.visitChildren(self)




    def atom(self):

        localctx = GramaticaParser.AtomContext(self, self._ctx, self.state)
        self.enterRule(localctx, 44, self.RULE_atom)
        try:
            self.state = 240
            self._errHandler.sync(self)
            la_ = self._interp.adaptivePredict(self._input,20,self._ctx)
            if la_ == 1:
                self.enterOuterAlt(localctx, 1)
                self.state = 231
                self.match(GramaticaParser.PARENTESIS_APERTURA)
                self.state = 232
                self.expr()
                self.state = 233
                self.match(GramaticaParser.PARENTESIS_CIERRE)
                pass

            elif la_ == 2:
                self.enterOuterAlt(localctx, 2)
                self.state = 235
                self.llamada_funcion()
                pass

            elif la_ == 3:
                self.enterOuterAlt(localctx, 3)
                self.state = 236
                self.match(GramaticaParser.VARIABLE)
                pass

            elif la_ == 4:
                self.enterOuterAlt(localctx, 4)
                self.state = 237
                self.match(GramaticaParser.NUMERO)
                pass

            elif la_ == 5:
                self.enterOuterAlt(localctx, 5)
                self.state = 238
                self.match(GramaticaParser.CADENA)
                pass

            elif la_ == 6:
                self.enterOuterAlt(localctx, 6)
                self.state = 239
                self.match(GramaticaParser.BOOLEANO)
                pass


        except RecognitionException as re:
            localctx.exception = re
            self._errHandler.reportError(self, re)
            self._errHandler.recover(self, re)
        finally:
            self.exitRule()
        return localctx





